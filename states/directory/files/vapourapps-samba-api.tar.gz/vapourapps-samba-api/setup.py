from setuptools import setup

setup(
  name='va_samba_api',
  version=__import__('va_samba_api').__version__,
  author='Vapour Apps',
  packages=['va_samba_api']
)
