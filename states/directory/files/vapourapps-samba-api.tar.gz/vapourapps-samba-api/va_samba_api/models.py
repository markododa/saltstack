import sqlite3
import os
from peewee import *

DB_PATH = os.environ.get('SAMBA_API_DB_PATH', '/vapour/data/samba_cache.db')
db = SqliteDatabase(DB_PATH)
db.connect()


class User(Model):
    username = CharField()
    name = CharField()
    password_expiry = DateTimeField(null=True)
    last_logon = DateTimeField(null=True)
    flags = CharField(null=True)
    is_locked = BooleanField()
    ip_address = CharField(null=True)
    computer = CharField(null=True)

    class Meta:
        database = db


# This always runs, but only creates tables if they don't exists
db.create_tables([User], True)
