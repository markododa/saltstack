import samba
import ldb
import subprocess
import re
import datetime
import json
from .models import db, User
from .utils import *
from samba.credentials import Credentials, DONT_USE_KERBEROS
from samba.auth import system_session
from samba.netcmd.common import netcmd_get_domain_infos_via_cldap
from samba.samdb import SamDB
from ldb import SCOPE_SUBTREE, SCOPE_BASE
from samba import param, dsdb
from samba.provision import ProvisionNames, provision_paths_from_lp
from samba.param import LoadParm

__version__ = '0.0.1'


lp = LoadParm()
lp.load_default()
smbconf = lp.configfile
creds = Credentials()
creds.guess(lp)
session = system_session()
def get_paths():
    smbconf = param.default_path()
    lp = param.LoadParm()
    lp.load(smbconf)
    return provision_paths_from_lp(lp, 'foo')
paths = get_paths()
sam_ldb = SamDB(url=paths.samdb, session_info=session, credentials=creds, lp=lp)


def get_cur_domain():
    """Returns the domain name of the local Samba directory."""
    res = netcmd_get_domain_infos_via_cldap(lp, None, '127.0.0.1')
    return res.dns_domain


def list_users(auto_build_cache=True):
    """Returns a list of all users (and their pdb data)"""
    # Samba has a minimum of 1 user. If there are none in the cache, it means
    # that the cache is empty and we have to build it
    if auto_build_cache and User.select().count() == 0:
        build_cache()

    users = []
    for user in User.select():
        # .data is an internal dict that contains the fields.
        # TODO: use playhouse.object_to_dict
        users.append(user._data)
    return users


def delete_user(username):
    sam_ldb.deleteuser(username)
    this_user = User.get(User.username == username)
    this_user.delete_instance()


def change_name(username, new_name):
    """Finds a Samba user by username and then sets it's full name"""
    try:
        subprocess.check_output(['pdbedit', '-u' + username, '-f' + new_name],
                                stderr=subprocess.STDOUT)
    except subprocess.CalledProcessError as exc:
        raise SambaProcessError(exc)

    this_user = get_user_by_username(username)
    this_user.name = new_name
    this_user.save()


def add_user(username, password, name, surname, vpn):
    """Adds a new user to Samba and then puts it into cache"""
    try:
        sam_ldb.newuser(username, password)
        user_data = get_pdb_details(username)
        subprocess.check_output(['pdbedit', '-u' + username, '-f%s %s' % (name, surname)],
                                stderr=subprocess.STDOUT)
    except subprocess.CalledProcessError as exc:
        raise SambaProcessError(exc)

    # The caching part...
    user = User(username=username, name='%s %s' % (name, surname),
                password_expiry=user_data['password_expiry'],
                is_locked=user_data['is_locked'], flags=user_data['flags'])
    user.save()
    if vpn:
        create_vpn_cert(username)


def change_password(username, password, again_at_login=False):
    sam_filter = get_filter_from_username(username)
    sam_ldb.setpassword(sam_filter, password, force_change_at_next_login=again_at_login, username=username)
    try:
        user_data = get_pdb_details(username)
        # After updating Samba, update password expiry date in the cache
        user = get_user_by_username(username)
        user.password_expiry = user_data['password_expiry']
        user.save()
    except subprocess.CalledProcessError:
        raise SambaProcessError(exc)


def list_dns():
    from samba.dcerpc import dnsp, dnsserver
    server = '127.0.0.1'
    binding_str = 'ncacn_ip_tcp:%s[sign]' % server
    creds = Credentials()
    creds.guess(lp)
    creds.set_username('VapourAdmin')
    creds.set_password('lP55x23n84nNlz4B9')
    dns_conn = dnsserver.dnsserver(binding_str, lp, creds)
    zone = get_cur_domain()
    name = '@'
    record_type = dnsp.DNS_TYPE_ALL
    select_flags = dnsserver.DNS_RPC_VIEW_AUTHORITY_DATA
    
    buflen, res = dns_conn.DnssrvEnumRecords2(
            dnsserver.DNS_CLIENT_VERSION_LONGHORN, 0, server, zone, name,
            None, record_type, select_flags, None, None
    )
    record_groups = res.rec
    
    #result = {'A': [], 'AAAA': [], 'PTR': [], 'NS': [], 'CNAME': [], 'SOA': [], 'MX': [], 'SRV': [], 'TXT': []}
    result = []
    for rec_group in record_groups:
        group_name = rec_group.dnsNodeName.str
        for rec in rec_group.records:
            if rec.wType == dnsp.DNS_TYPE_A:
                result.append({'group_name': group_name, 'type': 'A', 'value': rec.data})
            elif rec.wType == dnsp.DNS_TYPE_AAAA:
                result.append({'group_name': group_name, 'type': 'AAAA', 'value': rec.data})
            elif rec.wType == dnsp.DNS_TYPE_PTR:
                result.append({'group_name': group_name, 'type': 'PTR', 'value': rec.data.str})
            elif rec.wType == dnsp.DNS_TYPE_NS:
                result.append({'group_name': group_name, 'type': 'NS', 'value': rec.data.str})
            elif rec.wType == dnsp.DNS_TYPE_CNAME:
                result.append({'group_name': group_name, 'type': 'CNAME', 'value': rec.data.str})
            elif rec.wType == dnsp.DNS_TYPE_SOA:
                result.append({
                    'group_name': group_name,
                    'type': 'SOA',
                    'value': 'serial=%d, refresh=%d, retry=%d, expire=%d, minttl=%d, ns=%s, email=%s' % (
                        rec.data.dwSerialNo,
                        rec.data.dwRefresh,
                        rec.data.dwRetry,
                        rec.data.dwExpire,
                        rec.data.dwMinimumTtl,
                        rec.data.NamePrimaryServer.str,
                        rec.data.ZoneAdministratorEmail.str
                    )
                })
            elif rec.wType == dnsp.DNS_TYPE_MX:
                result['MX'].append((rec.data.nameExchange.str, rec.data.wPreference))
                result.append({'group_name': group_name, 'type': 'MX', 'value': '%s (%d)' % (rec.data.str, rec.data.wPreference)})
            elif rec.wType == dnsp.DNS_TYPE_SRV:
                result.append({'group_name': group_name, 'type': 'SRV', 'value': '%s (%d, %d, %d)' % (
                    rec.data.nameTarget.str, rec.data.wPort,
                    rec.data.wPriority, rec.data.wWeight
                )})
            elif rec.wType == dnsp.DNS_TYPE_TXT:
                slist = ['"%s"' % name.str for name in rec.data.str]
                result.append({'group_name': group_name, 'type': 'TXT', 'value': ','.join(slist)})
    return result


def add_dns_entry(name, entry_type, address):
    
    try:
        samba_tool(["dns", "add", "localhost", get_cur_domain(), name,
                    entry_type, address])
    except subprocess.CalledProcessError as exc:
        raise SambaProcessError(exc)


def list_groups():
    domain_dn = sam_ldb.domain_dn()
    res = sam_ldb.search(domain_dn, scope=ldb.SCOPE_SUBTREE,
                       expression=("(objectClass=group)"),
                       attrs=["samaccountname", "grouptype"])
    if len(res) == 0:
        return
    else:
        return [msg.get("samaccountname", idx=0) for msg in res]

def add_group(name):
    sam_ldb.newgroup(name)


def list_group_members(group_name):
    members = samba_tool(['group', 'listmembers', group_name])
    return members.rstrip('\n').split('\n')


def set_user_status(username, lock):
    """Locks or unlocks a specific user."""
    sam_filter = get_filter_from_username(username)
    func = {
        True: sam_ldb.disable_account,  # if lock
        False: sam_ldb.enable_account   # if not lock
    }
    func[lock](sam_filter)
    user = get_user_by_username(username)
    user_data = get_pdb_details(username)
    for user_data_key in user_data.keys():
        setattr(user, user_data_key, user_data[user_data_key])
    user.save()

def add_alias(username, alias):
    def get_user_dn(ldb_instance, search_filter):
        res = ldb_instance.search(
            base=str(ldb_instance.get_default_basedn()),
            scope=ldb.SCOPE_SUBTREE,
            expression=search_filter, attrs=['userAccountControl']
        )

        if len(res) == 0:
            raise ValueError()
        assert(len(res) == 1)
        return res[0].dn

    username_filter = get_filter_from_username(username)
    user_dn = get_user_dn(sam_ldb, username_filter)
    mod = '\n' + 'dn: %s' % user_dn + '\n' + \
          'changetype: modify' + '\n' + \
          'add: proxyAddresses' + '\n' + \
          'proxyAddresses: SMTP:%s' % alias + '\n'
    sam_ldb.modify_ldif(mod)
    
# Caching system
# It is used for fast API data retrieval, because Samba is really slow.


def purge_cache():
    """Deletes all the cache by removing all tables' rows"""
    User.delete().execute()  # Deletes ALL users from cache


def build_cache():
    """Imports all users from Samba and bulk inserts them into cache"""
    search_string = '(&(objectClass=user)(userAccountControl:%s:=%u))'
    res = sam_ldb.search(sam_ldb.domain_dn(), scope=ldb.SCOPE_SUBTREE,
                         expression=search_string % (ldb.OID_COMPARATOR_AND, dsdb.UF_NORMAL_ACCOUNT),
                         attrs=['samaccountname'])
    if not len(res):
        raise Exception("Cant't find any user!")
    else:
        users = [msg.get('samaccountname', idx=0) for msg in res]

    with db.atomic():
        for username in users:
            try:
                user_data = get_pdb_details(username)
            except subprocess.CalledProcessError:
                continue  # ATM, we do not care if a single PDB request fails
            user = get_user_by_username(user_data['username'])
            if user is None:  # User doesn't exist in cache, insert it
                new_user = User(**user_data)
                new_user.save()
            else:  # Users exists in cache, update data
                for user_data_key in user_data.keys():
                    setattr(user, user_data_key, user_data[user_data_key])
                user.save()
